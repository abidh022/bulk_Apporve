
//sakthi code
async function filterRecords() {
    let filtered_flag = false;
    let Module = document.getElementById('modules-list');
    let searchInput = document.getElementById('record-name-filter-input');
    let recordName_filter_type = document.getElementById('record-name-filter');
    let searchBtn = document.getElementById('cta_filter');
    let clearBtn = document.getElementById('cta_clear_filter');


    // searchInput.placeholder = t["record-name-filter-input"];
    // searchBtn.title = t["tooltip_search_btn"] || "Enter text to search";

    searchBtn.disabled = true;
    searchBtn.style.opacity = "0.5";
    searchBtn.style.cursor = "not-allowed";

    // Enable/disable search button based on input
    searchInput.addEventListener('input', () => {
        const hasText = searchInput.value.trim().length > 0;
        searchBtn.disabled = !hasText;
        searchBtn.style.opacity = hasText ? "1" : "0.5";
        searchBtn.style.cursor = hasText ? "pointer" : "not-allowed";
    });

    searchBtn.addEventListener('click', async (e) => {
        e.preventDefault();
    
        const searchValue = searchInput.value.trim().toLowerCase();
        if (!searchValue) {
            ZAGlobal.triggerToast(tt("toast_enter_search_key"), 1000, 'info');
            return;
        }

        const selectedModule = Module?.value || 'All_Modules';

        // 🔍 Get fresh base records from allRecords, not filteredRecords
        let baseRecords = [...ZAGlobal.allRecords];

        // 🔁 Apply user-based filtering
        if (ZAGlobal.isSelfAndSubordinates) {
            // No need to filter by user
        } else if (ZAGlobal.selectedUserId) {
            baseRecords = baseRecords.filter(r => r.waiting_for?.id === ZAGlobal.selectedUserId);
        } else {
            baseRecords = baseRecords.filter(r => r.waiting_for?.id === ZAGlobal.currentUserId);
        }

        // 🔁 Apply module filter if not "All"
        if (selectedModule !== 'All_Modules') {
            baseRecords = baseRecords.filter(r => r.module === selectedModule);
        }

        // 🔁 Apply record name filter
        let finalFiltered = [];
        switch (recordName_filter_type.value) {
            case 'equals':
                finalFiltered = baseRecords.filter(r =>
                    r.entity.name.toLowerCase().includes(searchValue)
                );
                break;
            case 'not_equals':
                finalFiltered = baseRecords.filter(r =>
                    !r.entity.name.toLowerCase().includes(searchValue)
                );
                break;
            case 'starts_with':
                finalFiltered = baseRecords.filter(r =>
                    r.entity.name.toLowerCase().startsWith(searchValue)
                );
                break;
            case 'is':
                finalFiltered = baseRecords.filter(r =>
                    r.entity.name.toLowerCase() === searchValue
                );
                break;
            default:
                console.warn("Unknown filter type");
                break;
        }

        ZAGlobal.filteredRecords = finalFiltered;
        filtered_flag = true;
        await ZAGlobal.reRenderTableBody();
    });

clearBtn.addEventListener('click', async (e) => {
    e.preventDefault();

    if (filtered_flag) {
        filtered_flag = false;
        searchInput.value = '';
        searchBtn.disabled = true;
        searchBtn.style.opacity = "0.5";
        searchBtn.style.cursor = "not-allowed";

        document.getElementById('record-name-filter-input').value = '';
        $('#module').val('All_Modules').trigger('change');
        document.getElementById('selected-module-display').style.display = 'none';

        // Reapply base filters based on current user context
        let baseRecords = [];

        if (ZAGlobal.isSelfAndSubordinates) {
            baseRecords = [...ZAGlobal.allRecords];
        } else if (ZAGlobal.self === false) {
            baseRecords = ZAGlobal.allRecords.filter(
            rec => rec.waiting_for?.id === ZAGlobal.selectedUserId);
        } else {
            baseRecords = [...ZAGlobal.ownAwaitingRecords];
        }

        ZAGlobal.filteredRecords = baseRecords;
        await ZAGlobal.reRenderTableBody();
    } else {
        ZAGlobal.triggerToast(tt("toast_nothing_to_clear"), 1000, 'info');
    }
});

}

document.getElementById('filter-icon').addEventListener('click', (e) => {
    e.preventDefault();

    const moduleContainer = document.querySelector('#moduleContainer');
    const filterDiv = document.querySelector('.filter-div');
    const moduleSelect = $('#module'); // jQuery Select2
    const modulePlaceholder = document.getElementById('module-placeholder');

    const isNowHidden = filterDiv.classList.toggle('hidden');

    if (!isNowHidden) {
        moduleSelect.select2('destroy');
        moduleSelect.hide();
        modulePlaceholder.style.display = 'inline-block';
    } else {
        moduleSelect.show();
        modulePlaceholder.style.display = 'none';

        // ⚠️ Delay reinitialization slightly to ensure proper layout
        setTimeout(() => {
            moduleSelect.select2();
        }, 10); // 10–50ms is usually enough
    }
});