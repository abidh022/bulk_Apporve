var initialRows;
var ZAGlobal = {
    selectedRecords: [],
    allRecords: [],
    filteredRecords: [],
    processedRecords: [],
    waitingRecords: [],
    recordsPerPage: 10,
    currentPage: 1,
    totalPages: 0,

    reRenderTableBody: async function () {
        $('._tbody').empty();
        var tbody = '';

        const headerCheckbox = document.querySelector('#selectAllCheckbox');
        if (headerCheckbox) headerCheckbox.disabled = false;


        if (!ZAGlobal.domainName || !ZAGlobal.orgId) {
            try {
                const envData = await ZOHO.CRM.CONFIG.GetCurrentEnvironment();
                const deployment = (envData.deployment || 'IN').toLowerCase();
                switch (deployment) {
                    case 'us':
                        ZAGlobal.domainName = 'com';
                        break;
                    case 'in':
                        ZAGlobal.domainName = 'in';
                        break;
                    default:
                        ZAGlobal.domainName = 'com';
                }
                const orgInfo = await ZOHO.CRM.CONFIG.getOrgInfo();
                ZAGlobal.orgId = orgInfo.org[0].domain_name;
            } catch (error) {
                console.error('Error fetching deployment or org info:', error);
                ZAGlobal.triggerToast(tt("toast_fetch_org_error"), 3000, 'error');
            }
        }

        const noRecords = !Array.isArray(ZAGlobal.allRecords) || ZAGlobal.allRecords.length === 0;
        const noFilteredRecords = !Array.isArray(ZAGlobal.filteredRecords) || ZAGlobal.filteredRecords.length === 0;

        if (noRecords || noFilteredRecords) {
            const noRecordsMessage = noRecords
                ? (t["custom.APPROVAL.noRecordsAvailable"] || "No records found")
                : (t["custom.APPROVAL.noFilteredRecords"] || "No records match your filter");
            $('._tbody').html(`
                <tr>
                <td colspan="8" style="text-align: center; padding: 20px;">
                    <img class="img" src="no_record_img.jpg" alt="No records">
                    <div>${noRecordsMessage}</div>
                </td>
                </tr>
                `);
            if (headerCheckbox) {
                headerCheckbox.disabled = true;
                headerCheckbox.checked = false;
                headerCheckbox.indeterminate = false;
            }
            ZAGlobal.updatePagination();
            resetHeaderCheckbox();
            updateSelectedCount();
            updateSelectAllCheckboxState();

            const totalCountEl = document.getElementById('totalRecordsCount');
            if (totalCountEl) {
                const label = t["custom.APPROVAL.totalRecordsCount"];
                totalCountEl.innerHTML = `${label}: ${'0'}`;
            }
            // ZAGlobal.updatePagination();
            // updateSelectedCount();
            return;
        }
        else {
            if (headerCheckbox) {
                headerCheckbox.disabled = false;
            }

            // Apply pagination
            var startIndex = (ZAGlobal.currentPage - 1) * ZAGlobal.recordsPerPage;
            var endIndex = startIndex + ZAGlobal.recordsPerPage;
            var recordsToShow = ZAGlobal.filteredRecords.slice(startIndex, endIndex);

            recordsToShow.forEach(function (record) {

                var initiatedTime = new Date(record.initiated_time);
                var currentTime = new Date();
                var timeDiff = currentTime - initiatedTime;
                var daysAgo = Math.floor(timeDiff / (1000 * 3600 * 24));
                var options = {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                };
                let safeLocale = ['en', 'zh'].includes(ZAGlobal.userLang) ? ZAGlobal.userLang : 'en';
                var formattedDate = initiatedTime.toLocaleString( safeLocale, options);

                tbody += `<tr data-id="${record.entity.id}" data-module="${record.module}">
                            <td><input type="checkbox" data-id="${record.entity.id}" data-module="${record.module}" ${ZAGlobal.selectedRecords.includes(record.entity.id) ? 'checked' : ''}></td>
                            <td><a href= "https://crm.zoho.${ZAGlobal.domainName}/crm/${ZAGlobal.orgId}/tab/${record.module}/${record.entity.id}" target="_blank" class="record-link">${record.entity.name}</a></td>
                            <td>${record.rule.name}</td>
                            <td>${t[`custom.APPROVAL.module.${record.module}`] || record.module}</td>
                            <td>${formattedDate}</td>
                            <td>${daysAgo} ${daysAgo === 1 ? tt("dayAgo") : tt("daysAgo")}</td>
                            <td class="action-buttons">
                                <button class="approve-btn" id="approve_single_action_btn" data-id="${record.entity.id}"><span class="btn-label"></span></button>
                                  <span class="slash">/</span>
                                <button class="delegate-btn" id="delegate_single_action_btn" data-id="${record.entity.id}"><span class="btn-label"></span></button>
                                  <span class="slash">/</span>
                                <button class="reject-btn" id="reject_single_action_btn" data-id="${record.entity.id}"><span class="btn-label"></span></button>
                            </td>
                            </tr>`;
                // console.log(record);
            });
            $('._tbody').append(tbody);
        }
        ZAGlobal.updatePagination();
        resetHeaderCheckbox();
        updateSelectedCount();
        updateSelectAllCheckboxState();

        // ✅ Updated logic to always show total or 0
        // const totalCountEl = document.getElementById('totalRecordsCount');
        // if (totalCountEl) {
        //     const total = Array.isArray(ZAGlobal.filteredRecords) ? ZAGlobal.filteredRecords.length : 0;
        //     const label = t["custom.APPROVAL.totalRecords"] || 'Total Records';
        //     totalCountEl.innerHTML = `${label}: ${total === 0 ? ('0') : `<strong>${total}</strong>`}`;
        // }

        const totalCountEl = document.getElementById('totalRecordsCount');
if (totalCountEl) {
    const total = Array.isArray(ZAGlobal.filteredRecords) ? ZAGlobal.filteredRecords.length : 0;
    const label = tt("totalRecordsCount");
    totalCountEl.innerHTML = `${label}: ${total === 0 ? ('0') : `<strong>${total}</strong>`}`;
}

        document.querySelectorAll('.approve-btn .btn-label').forEach(el => el.innerText = t["custom.APPROVAL.approve"]);
        document.querySelectorAll('.delegate-btn .btn-label').forEach(el => el.innerText = t["custom.APPROVAL.delegate"]);
        document.querySelectorAll('.reject-btn .btn-label').forEach(el => el.innerText = t["custom.APPROVAL.reject"]);

        let initialTBody = document.querySelector("._tbody");
        initialRows = Array.from(initialTBody.rows);
    },

    updatePagination: function () {
        var totalRecords = ZAGlobal.filteredRecords.length;
        ZAGlobal.totalPages = Math.ceil(totalRecords / ZAGlobal.recordsPerPage);

        var paginationHtml = `
            <span id="recordsLabel">${tt("paginationFooter")}</span>
            <select id="recordsPerPage">
                <option value="10" ${ZAGlobal.recordsPerPage === 10 ? 'selected' : ''}>10 </option>
                <option value="20" ${ZAGlobal.recordsPerPage === 20 ? 'selected' : ''}>20 </option>
                <option value="30" ${ZAGlobal.recordsPerPage === 30 ? 'selected' : ''}>30 </option>
                <option value="40" ${ZAGlobal.recordsPerPage === 40 ? 'selected' : ''}>40 </option>
                <option value="50" ${ZAGlobal.recordsPerPage === 50 ? 'selected' : ''}>50 </option>
                <option value="100" ${ZAGlobal.recordsPerPage === 100 ? 'selected' : ''}>100 </option>
            </select>
            <button id="prevPageBtn" ${ZAGlobal.currentPage === 1 ? 'disabled' : ''}></button>
            <span>${ZAGlobal.currentPage} - ${ZAGlobal.totalPages}</span>
            <button id="nextPageBtn" ${ZAGlobal.currentPage === ZAGlobal.totalPages ? 'disabled' : ''}> </button>
        `;
        $('#paginationFooter').html(paginationHtml);
        ZAGlobal.bindPaginationEvents();
    },

    bindPaginationEvents: function () {
        $('#recordsPerPage').on('change', function () {
            ZAGlobal.recordsPerPage = parseInt(this.value);
            ZAGlobal.currentPage = 1; ``
            ZAGlobal.reRenderTableBody();
        });

        $('#prevPageBtn').on('click', function () {
            if (ZAGlobal.currentPage > 1) {
                ZAGlobal.currentPage--;
                ZAGlobal.reRenderTableBody();
            }
        });

        $('#nextPageBtn').on('click', function () {
            if (ZAGlobal.currentPage < ZAGlobal.totalPages) {
                ZAGlobal.currentPage++;
                ZAGlobal.reRenderTableBody();
            }
        });
    }
};

let t = {};

ZOHO.embeddedApp.on("PageLoad", async function (data) {
    startNetworkMonitor();
    showLoader();
    const processingTextEl = document.querySelector('.processingTextId');
    if (processingTextEl) {
        processingTextEl.innerText = tt("custom.APPROVAL.processingText");
    }

    ZAGlobal.module = data.Entity;

    try {
        const toBeApproved = await ZOHO.CRM.API.getApprovalRecords({ type: "awaiting" });

        const records = Array.isArray(toBeApproved?.data) ? toBeApproved.data : [];

        ZAGlobal.filteredRecords = [...records];
        ZAGlobal.allRecords = [...records];
        ZAGlobal.waitingRecords = [...records];

        await ZAGlobal.reRenderTableBody();
    } catch (error) {
        console.error('Error fetching records:', error);
        ZAGlobal.triggerToast("Error loading records.", 3000, 'error');
    } finally {
        hideLoader(); 
    }

    ZOHO.CRM.META.getModules().then(function (data) {
        if (data && Array.isArray(data.modules)) {
            populateModules(data.modules);
        }
    });
    filterRecords()
}); 


// async function fetchAllApprovalRecords(type = "awaiting") {
//     let allRecords = [];
//     let page = 1;
//     let moreRecords = true;
//     const seenRecordIds = new Set();

//     console.log(`Starting fetchAllApprovalRecords with type: ${type}`);

//     while (moreRecords) {
//         console.log(`Fetching page ${page}...`);

//         try {
//             const response = await ZOHO.CRM.API.getApprovalRecords({
//                 type: type,
//                 page: page,
//                 per_page: 200
//             });

//             const currentPageRecords = Array.isArray(response?.data) ? response.data : [];
//             console.log(`Page ${page} returned ${currentPageRecords.length} records.`);

//             // Filter only *new* records
//             const newRecords = currentPageRecords.filter(record => !seenRecordIds.has(record.id));

//             if (newRecords.length === 0) {
//                 console.warn("No new records on this page. Possibly looping. Stopping.");
//                 break;
//             }

//             // Add new IDs to seen set and append to final list
//             newRecords.forEach(record => seenRecordIds.add(record.id));
//             allRecords = allRecords.concat(newRecords);

//             moreRecords = response?.info?.more_records || false;
//             console.log(`moreRecords flag is: ${moreRecords}`);
//             page += 1;

//             if (page > 100) {
//                 console.error("Too many pages, breaking to avoid infinite loop.");
//                 break;
//             }
//         } catch (error) {
//             console.error(`Error fetching page ${page}:`, error);
//             break;
//         }
//     }

//     console.log(`Fetched total ${allRecords.length} unique records.`);
//     return allRecords;
// }


// loop of 200 + records

// async function fetchAllApprovalRecords(type = "awaiting") {
//     let allRecords = [];
//     const seenRecordIds = new Set();
//     const maxPages = 10; 

//     console.log(`Starting fetchAllApprovalRecords with type: ${type}`);

//     for (let page = 1; page <= maxPages; page++) {
//         console.log(`Fetching page ${page}...`);

//         try {
//             const response = await ZOHO.CRM.API.getApprovalRecords({
//                 type: type,
//                 page: [1,2,3,4,5], 
//                 per_page: 200
//             });
//             console.log(response);
            

//             const currentPageRecords = Array.isArray(response?.data) ? response.data : [];
//             console.log(`Page ${page} returned ${currentPageRecords.length} records.`);

//             if (currentPageRecords.length === 0) {
//                 console.warn(`No records on page ${page}. Stopping.`);
//                 break;
//             }

//             // Filter and store only new records
//             const newRecords = currentPageRecords.filter(record => !seenRecordIds.has(record.id));
//             if (newRecords.length === 0) {
//                 console.warn(`All records on page ${page} are duplicates. Breaking.`);
//                 break;
//             }

//             newRecords.forEach(record => seenRecordIds.add(record.id));
//             allRecords = allRecords.concat(newRecords);

//             // Stop if less than a full page — indicates end
//             if (currentPageRecords.length < 200) {
//                 console.log(`Page ${page} had less than 200 records. Probably last page.`);
//                 break;
//             }

//         } catch (error) {
//             console.error(`Error fetching page ${page}:`, error);
//             break;
//         }
//     }

//     console.log(`Fetched total ${allRecords.length} unique records.`);
//     return allRecords;
// }

// async function fetchAllApprovalRecords(type = "awaiting") {
//     let allRecords = [];
//     const pages =[1,2,3]; 

//     console.log(`Fetching approval records of type: ${type}`);

//     // for (let page of pages) {
//     //     console.log(`Fetching page ${page}...`);
//     let moreRecords = true;
//     // while (moreRecords) { 
//         try {
//             const response = await ZOHO.CRM.API.getApprovalRecords({
//                 type: type,
//                 page: pages,
//                 per_page: 200
//             });
//             // moreRecords = response?.info?.more_records || false;
//             // pages += 1;
//             const records = Array.isArray(response?.data) ? response.data : [];
//             // console.log(`Page ${page} returned ${records.length} records.`);
//             allRecords = allRecords.concat(records);
//             console.log(response);
            

//         } catch (error) {
//             console.error(`Error fetching page ${page}:`, error);
//         }
//     // }
//     // }

//     console.log(`Fetched total ${allRecords.length} records.`);
//     return allRecords;
// }



// ZOHO.embeddedApp.on("PageLoad", async function (data) {
//     startNetworkMonitor();
//     showLoader();

//     const processingTextEl = document.querySelector('.processingTextId');
//     if (processingTextEl) {
//         processingTextEl.innerText = tt("custom.APPROVAL.processingText");
//     }

//     ZAGlobal.module = data.Entity;

//     try {
//         const allRecords = await fetchAllApprovalRecords("awaiting"); 
//         console.log(allRecords);
        
        
//         ZAGlobal.filteredRecords = [...allRecords];
//         ZAGlobal.allRecords = [...allRecords];
//         ZAGlobal.waitingRecords = [...allRecords];

//         await ZAGlobal.reRenderTableBody();
//     } catch (error) {
//         console.error('Error fetching records:', error);
//         ZAGlobal.triggerToast("Error loading records.", 3000, 'error');
//     } finally {
//         hideLoader();
//     }

//     ZOHO.CRM.META.getModules().then(function (data) {
//         if (data && Array.isArray(data.modules)) {
//             populateModules(data.modules);
//         }
//     });

//     filterRecords();
// });

// async function fetchAllApprovalRecords(type = "awaiting") {
//     let allRecords = [];
//     const perPage = 200;
//     const maxPages = 5;

//     for (let page = 1; page <= maxPages; page++) {
//         try {
//             const response = await ZOHO.CRM.API.getApprovalRecords({
//                 type: type,
//                 page: page,
//                 per_page: perPage
//             });

//             const records = Array.isArray(response?.data) ? response.data : [];
//             console.log(`Page ${page} returned ${records.length} record(s).`);

//             allRecords = allRecords.concat(records);

//         } catch (error) {
//             console.error(`Error fetching page ${page}:`, error);
//             break;
//         }
//     }
//     return allRecords;
// }       


// //padma code 
// async function fetchAllApprovalRecords(type = "awaiting") {
//     const allRecords = [];
//     const seenRecordIds = new Set();
//     let page = 1;
//     let moreRecords = true;

//     console.log(`Starting fetchAllApprovalRecords with type: ${type}`);

//     while (moreRecords) {
//         console.log(`Fetching page ${page}...`);

//         try {
//             const response = await ZOHO.CRM.API.getApprovalRecords({
//                 type,
//                 page,
//                 per_page: 200
//             });

//             const currentPageRecords = Array.isArray(response?.data) ? response.data : [];
//             console.log(`Page ${page} returned ${currentPageRecords.length} record(s).`);

//             const newRecords = currentPageRecords.filter(record => !seenRecordIds.has(record.id));

//             if (newRecords.length < currentPageRecords.length) {
//                 console.warn(`Page ${page} had ${currentPageRecords.length - newRecords.length} duplicate record(s).`);
//             }

//             if (newRecords.length === 0) {
//                 console.warn("No new records found. Possibly repeating pages. Exiting loop.");
//                 break;
//             }

//             newRecords.forEach(record => seenRecordIds.add(record.id));
//             allRecords.push(...newRecords); // More efficient than concat

//             moreRecords = response?.info?.more_records || false;
//             console.log(`moreRecords flag: ${moreRecords}`);
//             page += 1;

//             if (page > 100) {
//                 console.error("Too many pages. Stopping to avoid infinite loop.");
//                 break;
//             }

//         } catch (error) {
//             console.error(`Error on page ${page}:`, error);
//             break;
//         }
//     }

//     console.log(`Total unique records fetched: ${allRecords.length}`);
//     return allRecords;
// }

